# Notepad
It is java based notepad with various useful features like word count, array count, pointer location with various font size, styles and colors. 
